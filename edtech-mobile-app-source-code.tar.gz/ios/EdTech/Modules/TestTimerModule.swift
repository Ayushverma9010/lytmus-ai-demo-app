// ios/EdTech/Modules/TestTimerModule.swift
import Foundation
import UserNotifications

@objc(TestTimerModule)
class TestTimerModule: RCTEventEmitter {
    
    private var timer: Timer?
    private var backgroundTask: UIBackgroundTaskIdentifier = .invalid
    private var remainingSeconds: Int = 0
    private var testId: String = ""
    
    override static func moduleName() -> String! {
        return "TestTimerModule"
    }
    
    override func supportedEvents() -> [String]! {
        return ["onTimerTick", "onTimerComplete", "onAutoSubmitTest"]
    }
    
    override static func requiresMainQueueSetup() -> Bool {
        return true
    }
    
    // MARK: - Public Methods
    
    @objc
    func startTimer(
        _ durationInSeconds: Int,
        testId: String,
        resolver resolve: @escaping RCTPromiseResolveBlock,
        rejecter reject: @escaping RCTPromiseRejectBlock
    ) {
        DispatchQueue.main.async { [weak self] in
            guard let self = self else { return }
            
            // Stop any existing timer
            self.stopTimerInternal()
            
            // Request notification permissions
            self.requestNotificationPermission()
            
            // Begin background task
            self.beginBackgroundTask()
            
            // Initialize timer state
            self.remainingSeconds = durationInSeconds
            self.testId = testId
            
            // Save initial state
            self.saveTimerState()
            
            // Start the timer
            self.timer = Timer.scheduledTimer(
                withTimeInterval: 1.0,
                repeats: true
            ) { [weak self] _ in
                self?.timerTick()
            }
            
            // Ensure timer runs in background
            RunLoop.current.add(self.timer!, forMode: .common)
            
            resolve(true)
        }
    }
    
    @objc
    func pauseTimer(
        _ resolve: @escaping RCTPromiseResolveBlock,
        rejecter reject: @escaping RCTPromiseRejectBlock
    ) {
        stopTimerInternal()
        saveTimerState()
        resolve(true)
    }
    
    @objc
    func resumeTimer(
        _ remainingSeconds: Int,
        testId: String,
        resolver resolve: @escaping RCTPromiseResolveBlock,
        rejecter reject: @escaping RCTPromiseRejectBlock
    ) {
        startTimer(remainingSeconds, testId: testId, resolver: resolve, rejecter: reject)
    }
    
    @objc
    func stopTimer(
        _ resolve: @escaping RCTPromiseResolveBlock,
        rejecter reject: @escaping RCTPromiseRejectBlock
    ) {
        stopTimerInternal()
        resolve(true)
    }
    
    @objc
    func getTimerState(
        _ testId: String,
        resolver resolve: @escaping RCTPromiseResolveBlock,
        rejecter reject: @escaping RCTPromiseRejectBlock
    ) {
        let state = retrieveTimerState(for: testId)
        resolve(state)
    }
    
    // MARK: - Private Methods
    
    private func timerTick() {
        remainingSeconds -= 1
        
        // Send tick event to React Native
        sendEvent(
            withName: "onTimerTick",
            body: [
                "secondsRemaining": remainingSeconds,
                "testId": testId,
                "timestamp": Date().timeIntervalSince1970 * 1000
            ]
        )
        
        // Save progress every 5 seconds
        if remainingSeconds % 5 == 0 {
            saveTimerState()
        }
        
        // Show notification at 5 minutes remaining
        if remainingSeconds == 300 {
            scheduleNotification(title: "5 Minutes Remaining", body: "Complete your test soon!")
        }
        
        // Show notification at 1 minute remaining
        if remainingSeconds == 60 {
            scheduleNotification(title: "1 Minute Remaining", body: "Hurry! Test ending soon!")
        }
        
        // Timer complete
        if remainingSeconds <= 0 {
            timerComplete()
        }
    }
    
    private func timerComplete() {
        // Send completion event
        sendEvent(
            withName: "onTimerComplete",
            body: [
                "secondsRemaining": 0,
                "testId": testId,
                "timestamp": Date().timeIntervalSince1970 * 1000
            ]
        )
        
        // Auto-submit test
        sendEvent(
            withName: "onAutoSubmitTest",
            body: [
                "testId": testId,
                "reason": "timer_expired"
            ]
        )
        
        // Show completion notification
        scheduleNotification(
            title: "Test Time Over",
            body: "Your test has been automatically submitted."
        )
        
        // Cleanup
        stopTimerInternal()
    }
    
    private func stopTimerInternal() {
        timer?.invalidate()
        timer = nil
        endBackgroundTask()
    }
    
    // MARK: - Background Task Management
    
    private func beginBackgroundTask() {
        backgroundTask = UIApplication.shared.beginBackgroundTask { [weak self] in
            self?.endBackgroundTask()
        }
    }
    
    private func endBackgroundTask() {
        if backgroundTask != .invalid {
            UIApplication.shared.endBackgroundTask(backgroundTask)
            backgroundTask = .invalid
        }
    }
    
    // MARK: - Persistence
    
    private func saveTimerState() {
        let defaults = UserDefaults.standard
        defaults.set(remainingSeconds, forKey: "\(testId)_remaining")
        defaults.set(Date().timeIntervalSince1970, forKey: "\(testId)_timestamp")
        defaults.synchronize()
    }
    
    private func retrieveTimerState(for testId: String) -> [String: Any] {
        let defaults = UserDefaults.standard
        let remaining = defaults.integer(forKey: "\(testId)_remaining")
        let timestamp = defaults.double(forKey: "\(testId)_timestamp")
        
        return [
            "secondsRemaining": remaining,
            "timestamp": timestamp * 1000,
            "isActive": timer != nil
        ]
    }
    
    // MARK: - Notifications
    
    private func requestNotificationPermission() {
        UNUserNotificationCenter.current().requestAuthorization(
            options: [.alert, .sound, .badge]
        ) { granted, error in
            if let error = error {
                print("Notification permission error: \(error)")
            }
        }
    }
    
    private func scheduleNotification(title: String, body: String) {
        let content = UNMutableNotificationContent()
        content.title = title
        content.body = body
        content.sound = .default
        
        let trigger = UNTimeIntervalNotificationTrigger(timeInterval: 1, repeats: false)
        let request = UNNotificationRequest(
            identifier: UUID().uuidString,
            content: content,
            trigger: trigger
        )
        
        UNUserNotificationCenter.current().add(request) { error in
            if let error = error {
                print("Notification scheduling error: \(error)")
            }
        }
    }
    
    // MARK: - Cleanup
    
    deinit {
        stopTimerInternal()
    }
}
