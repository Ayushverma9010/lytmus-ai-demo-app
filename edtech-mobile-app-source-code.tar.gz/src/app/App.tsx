// src/app/App.tsx
import React, { useEffect } from 'react';
import { StatusBar, LogBox } from 'react-native';
import { GestureHandlerRootView } from 'react-native-gesture-handler';
import { SafeAreaProvider } from 'react-native-safe-area-context';
import { QueryClient, QueryClientProvider } from '@tanstack/react-query';
import { NavigationContainer } from '@react-navigation/native';
import NetInfo from '@react-native-community/netinfo';

import { ThemeProvider } from '@/design-system/ThemeProvider';
import { RootNavigator } from '@/navigation/RootNavigator';
import { ErrorBoundary } from '@/shared/components/ui/ErrorBoundary';
import { OfflineIndicator } from '@/shared/components/feedback/OfflineIndicator';
import { SyncManager } from '@/services/sync/SyncManager';
import { NotificationService } from '@/services/notification/NotificationService';
import { PerformanceMonitor } from '@/services/performance/PerformanceMonitor';
import { CrashlyticsService } from '@/services/analytics/CrashlyticsService';
import { logger } from '@/core/utils/logger';
import { linking } from '@/navigation/linking';
import '@/localization/i18n';

// Ignore specific warnings in production
if (__DEV__) {
  LogBox.ignoreLogs([
    'Non-serializable values were found in the navigation state',
  ]);
}

// React Query client configuration
const queryClient = new QueryClient({
  defaultOptions: {
    queries: {
      staleTime: 5 * 60 * 1000, // 5 minutes
      cacheTime: 10 * 60 * 1000, // 10 minutes
      retry: 3,
      retryDelay: (attemptIndex) => Math.min(1000 * 2 ** attemptIndex, 30000),
      refetchOnWindowFocus: false,
      refetchOnReconnect: true,
    },
    mutations: {
      retry: 2,
      retryDelay: 1000,
    },
  },
});

const App: React.FC = () => {
  useEffect(() => {
    // Initialize app services
    initializeApp();

    return () => {
      // Cleanup on unmount
      SyncManager.getInstance().stopSync();
    };
  }, []);

  const initializeApp = async () => {
    try {
      // Start performance monitoring
      PerformanceMonitor.start();

      // Initialize crash reporting
      await CrashlyticsService.initialize();

      // Setup notifications
      await NotificationService.initialize();

      // Subscribe to network state
      const unsubscribe = NetInfo.addEventListener((state) => {
        logger.info('Network state changed', { isConnected: state.isConnected });

        if (state.isConnected) {
          // Trigger background sync when online
          SyncManager.getInstance().triggerSync();
        }
      });

      // Start background sync
      SyncManager.getInstance().startSync();

      // Log app initialization
      logger.info('App initialized successfully');

      return unsubscribe;
    } catch (error) {
      logger.error('App initialization failed', error);
      CrashlyticsService.recordError(error as Error);
    }
  };

  return (
    <ErrorBoundary>
      <GestureHandlerRootView style={{ flex: 1 }}>
        <SafeAreaProvider>
          <QueryClientProvider client={queryClient}>
            <ThemeProvider>
              <NavigationContainer linking={linking}>
                <StatusBar
                  barStyle="dark-content"
                  backgroundColor="transparent"
                  translucent
                />
                <RootNavigator />
                <OfflineIndicator />
              </NavigationContainer>
            </ThemeProvider>
          </QueryClientProvider>
        </SafeAreaProvider>
      </GestureHandlerRootView>
    </ErrorBoundary>
  );
};

export default App;
