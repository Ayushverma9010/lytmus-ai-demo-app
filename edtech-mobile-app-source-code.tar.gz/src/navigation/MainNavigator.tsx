// src/navigation/MainNavigator.tsx
import React from 'react';
import { createBottomTabNavigator } from '@react-navigation/bottom-tabs';
import { createNativeStackNavigator } from '@react-navigation/native-stack';
import Icon from 'react-native-vector-icons/Ionicons';

import { DashboardScreen } from '@/features/dashboard/screens/DashboardScreen';
import { TestListScreen } from '@/features/tests/screens/TestListScreen';
import { TestScreen } from '@/features/tests/screens/TestScreen';
import { ReviewScreen } from '@/features/tests/screens/ReviewScreen';
import { ResultScreen } from '@/features/tests/screens/ResultScreen';
import { AnalyticsScreen } from '@/features/analytics/screens/AnalyticsScreen';
import { AITutorScreen } from '@/features/ai-tutor/screens/AITutorScreen';
import { ProfileScreen } from '@/features/profile/screens/ProfileScreen';
import { useTheme } from '@/design-system/ThemeProvider';
import { MainTabParamList, TestStackParamList } from './types';

const Tab = createBottomTabNavigator<MainTabParamList>();
const TestStack = createNativeStackNavigator<TestStackParamList>();

const TestNavigator: React.FC = () => {
  return (
    <TestStack.Navigator>
      <TestStack.Screen
        name="TestList"
        component={TestListScreen}
        options={{ title: 'Tests' }}
      />
      <TestStack.Screen
        name="TestDetail"
        component={TestListScreen}
        options={{ title: 'Test Details' }}
      />
      <TestStack.Screen
        name="TestAttempt"
        component={TestScreen}
        options={{
          title: 'Test',
          headerShown: false,
          gestureEnabled: false, // Prevent back gesture during test
        }}
      />
      <TestStack.Screen
        name="TestReview"
        component={ReviewScreen}
        options={{ title: 'Review' }}
      />
      <TestStack.Screen
        name="TestResult"
        component={ResultScreen}
        options={{ title: 'Result' }}
      />
      <TestStack.Screen
        name="Analytics"
        component={AnalyticsScreen}
        options={{ title: 'Analytics' }}
      />
    </TestStack.Navigator>
  );
};

export const MainNavigator: React.FC = () => {
  const theme = useTheme();

  return (
    <Tab.Navigator
      screenOptions={{
        headerShown: false,
        tabBarActiveTintColor: theme.colors.primary[500],
        tabBarInactiveTintColor: theme.colors.neutral[400],
        tabBarStyle: {
          backgroundColor: theme.colors.background,
          borderTopColor: theme.colors.border,
          height: 60,
          paddingBottom: 8,
          paddingTop: 8,
        },
        tabBarLabelStyle: {
          fontSize: 12,
          fontWeight: '600',
        },
      }}
    >
      <Tab.Screen
        name="Dashboard"
        component={DashboardScreen}
        options={{
          tabBarLabel: 'Dashboard',
          tabBarIcon: ({ color, size }) => (
            <Icon name="home" size={size} color={color} />
          ),
        }}
      />
      <Tab.Screen
        name="Tests"
        component={TestNavigator}
        options={{
          tabBarLabel: 'Tests',
          tabBarIcon: ({ color, size }) => (
            <Icon name="document-text" size={size} color={color} />
          ),
        }}
      />
      <Tab.Screen
        name="AITutor"
        component={AITutorScreen}
        options={{
          tabBarLabel: 'AI Tutor',
          tabBarIcon: ({ color, size }) => (
            <Icon name="chatbubbles" size={size} color={color} />
          ),
        }}
      />
      <Tab.Screen
        name="Profile"
        component={ProfileScreen}
        options={{
          tabBarLabel: 'Profile',
          tabBarIcon: ({ color, size }) => (
            <Icon name="person" size={size} color={color} />
          ),
        }}
      />
    </Tab.Navigator>
  );
};
