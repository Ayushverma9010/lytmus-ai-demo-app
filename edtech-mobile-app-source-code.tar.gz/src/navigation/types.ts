// src/navigation/types.ts
import { NavigatorScreenParams } from '@react-navigation/native';
import { NativeStackScreenProps } from '@react-navigation/native-stack';
import { BottomTabScreenProps } from '@react-navigation/bottom-tabs';

// Root Stack
export type RootStackParamList = {
  Auth: NavigatorScreenParams<AuthStackParamList>;
  Onboarding: undefined;
  Main: NavigatorScreenParams<MainTabParamList>;
};

// Auth Stack
export type AuthStackParamList = {
  Login: undefined;
  Signup: undefined;
  OTPVerification: { phone: string; verificationId: string };
  ForgotPassword: undefined;
};

// Main Tab Navigator
export type MainTabParamList = {
  Dashboard: undefined;
  Tests: NavigatorScreenParams<TestStackParamList>;
  AITutor: undefined;
  Profile: undefined;
};

// Test Stack
export type TestStackParamList = {
  TestList: undefined;
  TestDetail: { testId: string };
  TestAttempt: { testId: string; attemptId?: string };
  TestReview: { attemptId: string };
  TestResult: { attemptId: string };
  Analytics: { testId?: string };
};

// Type helpers for screens
export type RootStackScreenProps<T extends keyof RootStackParamList> =
  NativeStackScreenProps<RootStackParamList, T>;

export type AuthStackScreenProps<T extends keyof AuthStackParamList> =
  NativeStackScreenProps<AuthStackParamList, T>;

export type MainTabScreenProps<T extends keyof MainTabParamList> =
  BottomTabScreenProps<MainTabParamList, T>;

export type TestStackScreenProps<T extends keyof TestStackParamList> =
  NativeStackScreenProps<TestStackParamList, T>;

// Navigation props type helper
declare global {
  namespace ReactNavigation {
    interface RootParamList extends RootStackParamList {}
  }
}
