// src/features/tests/stores/testStore.ts
import { create } from 'zustand';
import { devtools } from 'zustand/middleware';
import { Test, Question, TestAttempt, Answer } from '../models/Test';
import { testService } from '../services/testService';
import { testRepository } from '../services/testRepository';
import { SyncQueue } from '@/services/sync/SyncQueue';
import { logger } from '@/core/utils/logger';

interface TestState {
  // Current test data
  currentTest: Test | null;
  currentAttempt: TestAttempt | null;
  answers: Record<string, Answer>; // questionId -> Answer
  timeRemaining: number; // in seconds
  currentQuestionIndex: number;
  isSubmitting: boolean;

  // Test list
  availableTests: Test[];
  isLoadingTests: boolean;

  // Actions
  loadTest: (testId: string) => Promise<void>;
  startTest: (testId: string) => Promise<void>;
  resumeTest: (attemptId: string) => Promise<void>;
  setAnswer: (questionId: string, answer: Answer) => Promise<void>;
  clearAnswer: (questionId: string) => Promise<void>;
  navigateToQuestion: (index: number) => void;
  updateTimer: (timeRemaining: number) => void;
  submitTest: () => Promise<void>;
  saveProgress: () => Promise<void>;
  loadAvailableTests: () => Promise<void>;
  reset: () => void;
}

export const useTestStore = create<TestState>()(
  devtools(
    (set, get) => ({
      currentTest: null,
      currentAttempt: null,
      answers: {},
      timeRemaining: 0,
      currentQuestionIndex: 0,
      isSubmitting: false,
      availableTests: [],
      isLoadingTests: false,

      loadTest: async (testId: string) => {
        try {
          logger.info('Loading test', { testId });

          // Try to load from local database first (offline-first)
          let test = await testRepository.getTest(testId);

          if (!test) {
            // If not in local DB, fetch from API
            test = await testService.getTest(testId);
            // Save to local DB for offline access
            await testRepository.saveTest(test);
          }

          set({ currentTest: test });
          logger.info('Test loaded successfully', { testId });
        } catch (error) {
          logger.error('Failed to load test', error);
          throw error;
        }
      },

      startTest: async (testId: string) => {
        try {
          const { currentTest } = get();
          if (!currentTest || currentTest.id !== testId) {
            await get().loadTest(testId);
          }

          const test = get().currentTest;
          if (!test) throw new Error('Test not loaded');

          // Create new attempt
          const attempt: TestAttempt = {
            id: `attempt_${Date.now()}`,
            testId,
            userId: 'current_user_id', // Get from auth store
            startedAt: Date.now(),
            status: 'in_progress',
            answers: {},
            timeSpent: 0,
          };

          // Save attempt locally
          await testRepository.saveAttempt(attempt);

          set({
            currentAttempt: attempt,
            answers: {},
            timeRemaining: test.duration,
            currentQuestionIndex: 0,
          });

          logger.info('Test started', { testId, attemptId: attempt.id });
        } catch (error) {
          logger.error('Failed to start test', error);
          throw error;
        }
      },

      resumeTest: async (attemptId: string) => {
        try {
          // Load attempt from local DB
          const attempt = await testRepository.getAttempt(attemptId);
          if (!attempt) throw new Error('Attempt not found');

          // Load test
          await get().loadTest(attempt.testId);

          set({
            currentAttempt: attempt,
            answers: attempt.answers,
            timeRemaining: attempt.timeRemaining || 0,
          });

          logger.info('Test resumed', { attemptId });
        } catch (error) {
          logger.error('Failed to resume test', error);
          throw error;
        }
      },

      setAnswer: async (questionId: string, answer: Answer) => {
        const { currentAttempt, answers } = get();
        if (!currentAttempt) throw new Error('No active test attempt');

        const newAnswers = { ...answers, [questionId]: answer };
        set({ answers: newAnswers });

        // Save locally immediately (offline-first)
        await testRepository.saveAnswer(currentAttempt.id, questionId, answer);

        // Queue for cloud sync
        await SyncQueue.add({
          operation: 'UPDATE',
          entity: 'test_answer',
          payload: {
            attemptId: currentAttempt.id,
            questionId,
            answer,
          },
        });

        logger.debug('Answer saved', { questionId, attemptId: currentAttempt.id });
      },

      clearAnswer: async (questionId: string) => {
        const { currentAttempt, answers } = get();
        if (!currentAttempt) throw new Error('No active test attempt');

        const newAnswers = { ...answers };
        delete newAnswers[questionId];
        set({ answers: newAnswers });

        // Update locally
        await testRepository.deleteAnswer(currentAttempt.id, questionId);

        // Queue for cloud sync
        await SyncQueue.add({
          operation: 'DELETE',
          entity: 'test_answer',
          payload: {
            attemptId: currentAttempt.id,
            questionId,
          },
        });
      },

      navigateToQuestion: (index: number) => {
        set({ currentQuestionIndex: index });
      },

      updateTimer: (timeRemaining: number) => {
        const { currentAttempt } = get();
        set({ timeRemaining });

        // Save time remaining every 5 seconds
        if (currentAttempt && timeRemaining % 5 === 0) {
          testRepository.updateTimeRemaining(currentAttempt.id, timeRemaining);
        }
      },

      submitTest: async () => {
        const { currentAttempt, answers } = get();
        if (!currentAttempt) throw new Error('No active test attempt');

        set({ isSubmitting: true });

        try {
          // Update attempt status
          const completedAttempt: TestAttempt = {
            ...currentAttempt,
            answers,
            completedAt: Date.now(),
            status: 'completed',
          };

          // Save locally
          await testRepository.saveAttempt(completedAttempt);

          // Queue for cloud sync (high priority)
          await SyncQueue.add({
            operation: 'UPDATE',
            entity: 'test_attempt',
            payload: completedAttempt,
            priority: 'high',
          });

          // Try to submit to server immediately if online
          try {
            await testService.submitTest(completedAttempt);
            logger.info('Test submitted to server', { attemptId: currentAttempt.id });
          } catch (error) {
            // If offline, it will be synced later
            logger.warn('Failed to submit to server (will retry)', error);
          }

          set({
            currentAttempt: completedAttempt,
            isSubmitting: false,
          });

          logger.info('Test submitted successfully', { attemptId: currentAttempt.id });
        } catch (error) {
          set({ isSubmitting: false });
          logger.error('Failed to submit test', error);
          throw error;
        }
      },

      saveProgress: async () => {
        const { currentAttempt, answers, timeRemaining } = get();
        if (!currentAttempt) return;

        try {
          const updatedAttempt: TestAttempt = {
            ...currentAttempt,
            answers,
            timeRemaining,
            lastSavedAt: Date.now(),
          };

          await testRepository.saveAttempt(updatedAttempt);
          logger.debug('Progress saved', { attemptId: currentAttempt.id });
        } catch (error) {
          logger.error('Failed to save progress', error);
        }
      },

      loadAvailableTests: async () => {
        set({ isLoadingTests: true });
        try {
          // Try local first
          let tests = await testRepository.getAvailableTests();

          // If empty or stale, fetch from API
          if (tests.length === 0) {
            tests = await testService.getAvailableTests();
            // Cache locally
            await Promise.all(tests.map(test => testRepository.saveTest(test)));
          }

          set({ availableTests: tests, isLoadingTests: false });
        } catch (error) {
          set({ isLoadingTests: false });
          logger.error('Failed to load tests', error);
          throw error;
        }
      },

      reset: () => {
        set({
          currentTest: null,
          currentAttempt: null,
          answers: {},
          timeRemaining: 0,
          currentQuestionIndex: 0,
          isSubmitting: false,
        });
      },
    }),
    { name: 'TestStore' }
  )
);
