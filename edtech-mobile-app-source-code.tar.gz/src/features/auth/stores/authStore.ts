// src/features/auth/stores/authStore.ts
import { create } from 'zustand';
import { persist, createJSONStorage } from 'zustand/middleware';
import { MMKV } from 'react-native-mmkv';
import { User } from '../models/User';
import { authService } from '../services/authService';
import { logger } from '@/core/utils/logger';

const storage = new MMKV({
  id: 'auth-storage',
  encryptionKey: 'your-encryption-key-from-env', // Load from secure source
});

// Zustand storage adapter for MMKV
const mmkvStorage = {
  getItem: (name: string) => {
    const value = storage.getString(name);
    return value ?? null;
  },
  setItem: (name: string, value: string) => {
    storage.set(name, value);
  },
  removeItem: (name: string) => {
    storage.delete(name);
  },
};

interface AuthState {
  user: User | null;
  accessToken: string | null;
  refreshToken: string | null;
  isAuthenticated: boolean;
  hasCompletedOnboarding: boolean;
  isLoading: boolean;
  error: string | null;

  // Actions
  login: (phone: string, password: string) => Promise<void>;
  loginWithOTP: (phone: string, otp: string) => Promise<void>;
  logout: () => Promise<void>;
  refreshAccessToken: () => Promise<void>;
  setUser: (user: User) => void;
  setTokens: (accessToken: string, refreshToken: string) => void;
  completeOnboarding: () => void;
  clearError: () => void;
}

export const useAuthStore = create<AuthState>()(
  persist(
    (set, get) => ({
      user: null,
      accessToken: null,
      refreshToken: null,
      isAuthenticated: false,
      hasCompletedOnboarding: false,
      isLoading: false,
      error: null,

      login: async (phone: string, password: string) => {
        set({ isLoading: true, error: null });
        try {
          const response = await authService.login(phone, password);
          
          set({
            user: response.user,
            accessToken: response.accessToken,
            refreshToken: response.refreshToken,
            isAuthenticated: true,
            isLoading: false,
          });

          logger.info('User logged in successfully', { userId: response.user.id });
        } catch (error) {
          const errorMessage = error instanceof Error ? error.message : 'Login failed';
          set({ error: errorMessage, isLoading: false });
          logger.error('Login failed', error);
          throw error;
        }
      },

      loginWithOTP: async (phone: string, otp: string) => {
        set({ isLoading: true, error: null });
        try {
          const response = await authService.verifyOTP(phone, otp);
          
          set({
            user: response.user,
            accessToken: response.accessToken,
            refreshToken: response.refreshToken,
            isAuthenticated: true,
            isLoading: false,
          });

          logger.info('User logged in with OTP', { userId: response.user.id });
        } catch (error) {
          const errorMessage = error instanceof Error ? error.message : 'OTP verification failed';
          set({ error: errorMessage, isLoading: false });
          logger.error('OTP verification failed', error);
          throw error;
        }
      },

      logout: async () => {
        set({ isLoading: true });
        try {
          // Call logout API if needed
          await authService.logout();

          // Clear all auth data
          set({
            user: null,
            accessToken: null,
            refreshToken: null,
            isAuthenticated: false,
            hasCompletedOnboarding: false,
            isLoading: false,
            error: null,
          });

          logger.info('User logged out');
        } catch (error) {
          logger.error('Logout failed', error);
          // Still clear local state even if API call fails
          set({
            user: null,
            accessToken: null,
            refreshToken: null,
            isAuthenticated: false,
            hasCompletedOnboarding: false,
            isLoading: false,
          });
        }
      },

      refreshAccessToken: async () => {
        const { refreshToken } = get();
        if (!refreshToken) {
          throw new Error('No refresh token available');
        }

        try {
          const response = await authService.refreshToken(refreshToken);
          
          set({
            accessToken: response.accessToken,
            refreshToken: response.refreshToken,
          });

          logger.info('Access token refreshed');
        } catch (error) {
          logger.error('Token refresh failed', error);
          // If refresh fails, logout user
          get().logout();
          throw error;
        }
      },

      setUser: (user: User) => {
        set({ user });
      },

      setTokens: (accessToken: string, refreshToken: string) => {
        set({ accessToken, refreshToken });
      },

      completeOnboarding: () => {
        set({ hasCompletedOnboarding: true });
        logger.info('Onboarding completed');
      },

      clearError: () => {
        set({ error: null });
      },
    }),
    {
      name: 'auth-storage',
      storage: createJSONStorage(() => mmkvStorage),
      partialize: (state) => ({
        // Only persist these fields
        user: state.user,
        accessToken: state.accessToken,
        refreshToken: state.refreshToken,
        isAuthenticated: state.isAuthenticated,
        hasCompletedOnboarding: state.hasCompletedOnboarding,
      }),
    }
  )
);
