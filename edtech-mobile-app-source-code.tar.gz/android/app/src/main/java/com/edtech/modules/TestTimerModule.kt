// android/app/src/main/java/com/edtech/modules/TestTimerModule.kt
package com.edtech.modules

import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.os.Build
import android.os.CountDownTimer
import android.os.PowerManager
import androidx.core.app.NotificationCompat
import com.facebook.react.bridge.*
import com.facebook.react.modules.core.DeviceEventManagerModule
import com.edtech.R
import com.edtech.services.TestTimerService
import kotlinx.coroutines.*

class TestTimerModule(reactContext: ReactApplicationContext) :
    ReactContextBaseJavaModule(reactContext) {

    companion object {
        private const val NAME = "TestTimerModule"
        private const val TIMER_TICK_EVENT = "onTimerTick"
        private const val TIMER_COMPLETE_EVENT = "onTimerComplete"
        private const val CHANNEL_ID = "test_timer_channel"
        private const val NOTIFICATION_ID = 1001
    }

    private var countDownTimer: CountDownTimer? = null
    private var wakeLock: PowerManager.WakeLock? = null
    private val scope = CoroutineScope(Dispatchers.Default + SupervisorJob())

    override fun getName(): String = NAME

    /**
     * Start a test timer with specified duration
     * @param durationInSeconds Total duration in seconds
     * @param testId Test identifier for tracking
     * @param promise Promise to resolve/reject
     */
    @ReactMethod
    fun startTimer(
        durationInSeconds: Int,
        testId: String,
        promise: Promise
    ) {
        try {
            // Cancel any existing timer
            stopTimer()

            // Create notification channel (Android O+)
            createNotificationChannel()

            // Acquire wake lock to keep CPU running
            acquireWakeLock(durationInSeconds.toLong() * 1000)

            // Start foreground service for reliable background execution
            val serviceIntent = Intent(reactApplicationContext, TestTimerService::class.java).apply {
                putExtra("DURATION", durationInSeconds.toLong() * 1000)
                putExtra("TEST_ID", testId)
            }

            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                reactApplicationContext.startForegroundService(serviceIntent)
            } else {
                reactApplicationContext.startService(serviceIntent)
            }

            // Create countdown timer
            countDownTimer = object : CountDownTimer(
                durationInSeconds.toLong() * 1000,
                1000 // Tick every second
            ) {
                override fun onTick(millisUntilFinished: Long) {
                    val secondsRemaining = (millisUntilFinished / 1000).toInt()
                    
                    // Emit event to React Native
                    sendEvent(TIMER_TICK_EVENT, createTimerData(secondsRemaining, testId))
                    
                    // Save progress to database (every 5 seconds)
                    if (secondsRemaining % 5 == 0) {
                        scope.launch {
                            saveTimerProgress(testId, secondsRemaining)
                        }
                    }
                }

                override fun onFinish() {
                    // Emit completion event
                    sendEvent(TIMER_COMPLETE_EVENT, createTimerData(0, testId))
                    
                    // Auto-submit test
                    scope.launch {
                        autoSubmitTest(testId)
                    }
                    
                    // Cleanup
                    cleanup()
                }
            }.start()

            promise.resolve(true)
        } catch (e: Exception) {
            promise.reject("TIMER_ERROR", "Failed to start timer: ${e.message}")
        }
    }

    /**
     * Pause the timer (if supported by test rules)
     */
    @ReactMethod
    fun pauseTimer(promise: Promise) {
        try {
            countDownTimer?.cancel()
            promise.resolve(true)
        } catch (e: Exception) {
            promise.reject("TIMER_ERROR", "Failed to pause timer: ${e.message}")
        }
    }

    /**
     * Resume a paused timer
     */
    @ReactMethod
    fun resumeTimer(
        remainingSeconds: Int,
        testId: String,
        promise: Promise
    ) {
        startTimer(remainingSeconds, testId, promise)
    }

    /**
     * Stop and cleanup timer
     */
    @ReactMethod
    fun stopTimer(promise: Promise? = null) {
        cleanup()
        promise?.resolve(true)
    }

    /**
     * Get current timer state
     */
    @ReactMethod
    fun getTimerState(testId: String, promise: Promise) {
        scope.launch {
            try {
                val state = retrieveTimerState(testId)
                promise.resolve(state)
            } catch (e: Exception) {
                promise.reject("TIMER_ERROR", "Failed to get timer state: ${e.message}")
            }
        }
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val name = "Test Timer"
            val descriptionText = "Shows timer for ongoing tests"
            val importance = NotificationManager.IMPORTANCE_LOW
            val channel = NotificationChannel(CHANNEL_ID, name, importance).apply {
                description = descriptionText
            }

            val notificationManager = reactApplicationContext
                .getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
            notificationManager.createNotificationChannel(channel)
        }
    }

    private fun acquireWakeLock(duration: Long) {
        val powerManager = reactApplicationContext
            .getSystemService(Context.POWER_SERVICE) as PowerManager
        
        wakeLock = powerManager.newWakeLock(
            PowerManager.PARTIAL_WAKE_LOCK,
            "EdTech::TestTimerWakeLock"
        ).apply {
            acquire(duration)
        }
    }

    private fun sendEvent(eventName: String, data: WritableMap) {
        reactApplicationContext
            .getJSModule(DeviceEventManagerModule.RCTDeviceEventEmitter::class.java)
            .emit(eventName, data)
    }

    private fun createTimerData(secondsRemaining: Int, testId: String): WritableMap {
        return Arguments.createMap().apply {
            putInt("secondsRemaining", secondsRemaining)
            putString("testId", testId)
            putDouble("timestamp", System.currentTimeMillis().toDouble())
        }
    }

    private suspend fun saveTimerProgress(testId: String, secondsRemaining: Int) {
        withContext(Dispatchers.IO) {
            try {
                // Save to local database
                // This should be implemented using Room or SQLite
                // For now, using SharedPreferences as example
                reactApplicationContext
                    .getSharedPreferences("test_timer", Context.MODE_PRIVATE)
                    .edit()
                    .putInt("${testId}_remaining", secondsRemaining)
                    .putLong("${testId}_timestamp", System.currentTimeMillis())
                    .apply()
            } catch (e: Exception) {
                // Log error but don't crash
                android.util.Log.e(NAME, "Failed to save timer progress", e)
            }
        }
    }

    private suspend fun autoSubmitTest(testId: String) {
        withContext(Dispatchers.IO) {
            try {
                // Trigger test submission via event
                val data = Arguments.createMap().apply {
                    putString("testId", testId)
                    putString("reason", "timer_expired")
                }
                sendEvent("onAutoSubmitTest", data)
            } catch (e: Exception) {
                android.util.Log.e(NAME, "Failed to auto-submit test", e)
            }
        }
    }

    private suspend fun retrieveTimerState(testId: String): WritableMap {
        return withContext(Dispatchers.IO) {
            val prefs = reactApplicationContext
                .getSharedPreferences("test_timer", Context.MODE_PRIVATE)
            
            val remaining = prefs.getInt("${testId}_remaining", 0)
            val timestamp = prefs.getLong("${testId}_timestamp", 0)
            
            Arguments.createMap().apply {
                putInt("secondsRemaining", remaining)
                putDouble("timestamp", timestamp.toDouble())
                putBoolean("isActive", countDownTimer != null)
            }
        }
    }

    private fun cleanup() {
        countDownTimer?.cancel()
        countDownTimer = null
        
        wakeLock?.let {
            if (it.isHeld) {
                it.release()
            }
        }
        wakeLock = null
        
        // Stop foreground service
        val serviceIntent = Intent(reactApplicationContext, TestTimerService::class.java)
        reactApplicationContext.stopService(serviceIntent)
    }

    override fun onCatalystInstanceDestroy() {
        super.onCatalystInstanceDestroy()
        cleanup()
        scope.cancel()
    }
}
