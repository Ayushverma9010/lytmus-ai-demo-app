// android/app/src/main/java/com/edtech/modules/AnalyticsModule.kt
package com.edtech.modules

import com.facebook.react.bridge.*
import kotlinx.coroutines.*
import org.json.JSONArray
import org.json.JSONObject
import kotlin.math.*

/**
 * Native Analytics Module
 * 
 * Performs heavy computational tasks for analytics on the native side
 * to avoid blocking the JavaScript thread. Includes:
 * - Detailed performance calculations
 * - Time distribution analysis
 * - Topic-wise accuracy computation
 * - Score prediction using linear regression
 * - Heatmap data generation
 */
class AnalyticsModule(reactContext: ReactApplicationContext) :
    ReactContextBaseJavaModule(reactContext) {

    companion object {
        private const val NAME = "AnalyticsModule"
    }

    private val scope = CoroutineScope(Dispatchers.Default + SupervisorJob())

    override fun getName(): String = NAME

    /**
     * Calculate comprehensive analytics from test attempts
     * 
     * @param attemptsJson JSON string containing array of test attempts
     * @param promise Promise to return calculated analytics
     */
    @ReactMethod
    fun calculateDetailedAnalytics(attemptsJson: String, promise: Promise) {
        scope.launch {
            try {
                val attempts = parseAttempts(attemptsJson)
                
                val analytics = withContext(Dispatchers.Default) {
                    AnalyticsResult(
                        overallAccuracy = calculateAccuracy(attempts),
                        topicAccuracy = calculateTopicAccuracy(attempts),
                        timeDistribution = calculateTimeDistribution(attempts),
                        difficultyPerformance = calculateDifficultyPerformance(attempts),
                        improvementTrend = calculateImprovementTrend(attempts),
                        weakTopics = identifyWeakTopics(attempts),
                        strongTopics = identifyStrongTopics(attempts),
                        predictedScore = predictNextScore(attempts),
                        confidenceScore = calculateConfidence(attempts),
                        heatmapData = generateHeatmapData(attempts),
                        timeAnalysis = analyzeTimeUsage(attempts)
                    )
                }
                
                promise.resolve(analytics.toWritableMap())
            } catch (e: Exception) {
                promise.reject("ANALYTICS_ERROR", "Failed to calculate analytics: ${e.message}")
            }
        }
    }

    /**
     * Generate heatmap data for time-per-question visualization
     */
    @ReactMethod
    fun generateTimeHeatmap(attemptsJson: String, promise: Promise) {
        scope.launch {
            try {
                val attempts = parseAttempts(attemptsJson)
                val heatmapData = generateHeatmapData(attempts)
                promise.resolve(heatmapData)
            } catch (e: Exception) {
                promise.reject("HEATMAP_ERROR", "Failed to generate heatmap: ${e.message}")
            }
        }
    }

    /**
     * Predict next test score using linear regression
     */
    @ReactMethod
    fun predictScore(scoresJson: String, promise: Promise) {
        scope.launch {
            try {
                val scores = JSONArray(scoresJson)
                val scoreList = mutableListOf<Double>()
                
                for (i in 0 until scores.length()) {
                    scoreList.add(scores.getDouble(i))
                }
                
                val prediction = simpleLinearRegression(scoreList)
                
                val result = Arguments.createMap().apply {
                    putDouble("predictedScore", prediction.predicted)
                    putDouble("confidence", prediction.confidence)
                    putDouble("trend", prediction.slope)
                }
                
                promise.resolve(result)
            } catch (e: Exception) {
                promise.reject("PREDICTION_ERROR", "Failed to predict score: ${e.message}")
            }
        }
    }

    // ============ Private Analytics Functions ============

    data class TestAttempt(
        val id: String,
        val score: Double,
        val totalQuestions: Int,
        val correctAnswers: Int,
        val timestamp: Long,
        val questions: List<QuestionAttempt>
    )

    data class QuestionAttempt(
        val id: String,
        val topic: String,
        val difficulty: String,
        val isCorrect: Boolean,
        val timeSpent: Int, // seconds
        val confidenceLevel: Int? // 1-5 scale
    )

    data class AnalyticsResult(
        val overallAccuracy: Double,
        val topicAccuracy: Map<String, Double>,
        val timeDistribution: Map<String, Double>,
        val difficultyPerformance: Map<String, Double>,
        val improvementTrend: ImprovementTrend,
        val weakTopics: List<TopicInsight>,
        val strongTopics: List<TopicInsight>,
        val predictedScore: ScorePrediction,
        val confidenceScore: Double,
        val heatmapData: WritableArray,
        val timeAnalysis: TimeAnalysis
    )

    data class ImprovementTrend(
        val slope: Double,
        val isImproving: Boolean,
        val improvementRate: Double // percentage
    )

    data class TopicInsight(
        val topic: String,
        val accuracy: Double,
        val questionsAttempted: Int,
        val averageTime: Double,
        val recommendation: String
    )

    data class ScorePrediction(
        val predicted: Double,
        val confidence: Double,
        val slope: Double
    )

    data class TimeAnalysis(
        val averageTimePerQuestion: Double,
        val fastestQuestions: List<String>,
        val slowestQuestions: List<String>,
        val timeEfficiencyScore: Double
    )

    private fun parseAttempts(json: String): List<TestAttempt> {
        val jsonArray = JSONArray(json)
        val attempts = mutableListOf<TestAttempt>()
        
        for (i in 0 until jsonArray.length()) {
            val obj = jsonArray.getJSONObject(i)
            val questionsArray = obj.getJSONArray("questions")
            val questions = mutableListOf<QuestionAttempt>()
            
            for (j in 0 until questionsArray.length()) {
                val q = questionsArray.getJSONObject(j)
                questions.add(
                    QuestionAttempt(
                        id = q.getString("id"),
                        topic = q.getString("topic"),
                        difficulty = q.getString("difficulty"),
                        isCorrect = q.getBoolean("isCorrect"),
                        timeSpent = q.getInt("timeSpent"),
                        confidenceLevel = if (q.has("confidenceLevel")) q.getInt("confidenceLevel") else null
                    )
                )
            }
            
            attempts.add(
                TestAttempt(
                    id = obj.getString("id"),
                    score = obj.getDouble("score"),
                    totalQuestions = obj.getInt("totalQuestions"),
                    correctAnswers = obj.getInt("correctAnswers"),
                    timestamp = obj.getLong("timestamp"),
                    questions = questions
                )
            )
        }
        
        return attempts
    }

    private fun calculateAccuracy(attempts: List<TestAttempt>): Double {
        if (attempts.isEmpty()) return 0.0
        
        val totalCorrect = attempts.sumOf { it.correctAnswers }
        val totalQuestions = attempts.sumOf { it.totalQuestions }
        
        return if (totalQuestions > 0) {
            (totalCorrect.toDouble() / totalQuestions) * 100
        } else 0.0
    }

    private fun calculateTopicAccuracy(attempts: List<TestAttempt>): Map<String, Double> {
        val topicStats = mutableMapOf<String, Pair<Int, Int>>() // topic -> (correct, total)
        
        attempts.forEach { attempt ->
            attempt.questions.forEach { question ->
                val (correct, total) = topicStats.getOrDefault(question.topic, Pair(0, 0))
                topicStats[question.topic] = Pair(
                    correct + if (question.isCorrect) 1 else 0,
                    total + 1
                )
            }
        }
        
        return topicStats.mapValues { (_, stats) ->
            (stats.first.toDouble() / stats.second) * 100
        }
    }

    private fun calculateTimeDistribution(attempts: List<TestAttempt>): Map<String, Double> {
        val timeRanges = mutableMapOf(
            "0-30s" to 0,
            "30-60s" to 0,
            "60-120s" to 0,
            "120s+" to 0
        )
        
        attempts.forEach { attempt ->
            attempt.questions.forEach { question ->
                when {
                    question.timeSpent <= 30 -> timeRanges["0-30s"] = timeRanges["0-30s"]!! + 1
                    question.timeSpent <= 60 -> timeRanges["30-60s"] = timeRanges["30-60s"]!! + 1
                    question.timeSpent <= 120 -> timeRanges["60-120s"] = timeRanges["60-120s"]!! + 1
                    else -> timeRanges["120s+"] = timeRanges["120s+"]!! + 1
                }
            }
        }
        
        val total = timeRanges.values.sum().toDouble()
        return timeRanges.mapValues { (it.value / total) * 100 }
    }

    private fun calculateDifficultyPerformance(attempts: List<TestAttempt>): Map<String, Double> {
        val difficultyStats = mutableMapOf<String, Pair<Int, Int>>()
        
        attempts.forEach { attempt ->
            attempt.questions.forEach { question ->
                val (correct, total) = difficultyStats.getOrDefault(question.difficulty, Pair(0, 0))
                difficultyStats[question.difficulty] = Pair(
                    correct + if (question.isCorrect) 1 else 0,
                    total + 1
                )
            }
        }
        
        return difficultyStats.mapValues { (_, stats) ->
            (stats.first.toDouble() / stats.second) * 100
        }
    }

    private fun calculateImprovementTrend(attempts: List<TestAttempt>): ImprovementTrend {
        if (attempts.size < 2) {
            return ImprovementTrend(0.0, false, 0.0)
        }
        
        val scores = attempts.sortedBy { it.timestamp }.map { it.score }
        val regression = simpleLinearRegression(scores)
        
        val improvementRate = if (scores.first() > 0) {
            ((scores.last() - scores.first()) / scores.first()) * 100
        } else 0.0
        
        return ImprovementTrend(
            slope = regression.slope,
            isImproving = regression.slope > 0,
            improvementRate = improvementRate
        )
    }

    private fun identifyWeakTopics(attempts: List<TestAttempt>): List<TopicInsight> {
        val topicAccuracy = calculateTopicAccuracy(attempts)
        
        return topicAccuracy
            .filter { it.value < 60.0 } // Weak = < 60% accuracy
            .map { (topic, accuracy) ->
                val questions = attempts.flatMap { it.questions }.filter { it.topic == topic }
                val avgTime = questions.map { it.timeSpent }.average()
                
                TopicInsight(
                    topic = topic,
                    accuracy = accuracy,
                    questionsAttempted = questions.size,
                    averageTime = avgTime,
                    recommendation = generateRecommendation(accuracy, avgTime)
                )
            }
            .sortedBy { it.accuracy }
            .take(5)
    }

    private fun identifyStrongTopics(attempts: List<TestAttempt>): List<TopicInsight> {
        val topicAccuracy = calculateTopicAccuracy(attempts)
        
        return topicAccuracy
            .filter { it.value >= 80.0 } // Strong = >= 80% accuracy
            .map { (topic, accuracy) ->
                val questions = attempts.flatMap { it.questions }.filter { it.topic == topic }
                val avgTime = questions.map { it.timeSpent }.average()
                
                TopicInsight(
                    topic = topic,
                    accuracy = accuracy,
                    questionsAttempted = questions.size,
                    averageTime = avgTime,
                    recommendation = "Maintain practice"
                )
            }
            .sortedByDescending { it.accuracy }
            .take(5)
    }

    private fun predictNextScore(attempts: List<TestAttempt>): ScorePrediction {
        if (attempts.size < 3) {
            return ScorePrediction(0.0, 0.0, 0.0)
        }
        
        val scores = attempts.sortedBy { it.timestamp }.map { it.score }
        val regression = simpleLinearRegression(scores)
        
        return ScorePrediction(
            predicted = regression.predicted.coerceIn(0.0, 100.0),
            confidence = regression.confidence,
            slope = regression.slope
        )
    }

    private fun calculateConfidence(attempts: List<TestAttempt>): Double {
        val questionsWithConfidence = attempts
            .flatMap { it.questions }
            .filter { it.confidenceLevel != null }
        
        if (questionsWithConfidence.isEmpty()) return 0.0
        
        return questionsWithConfidence
            .map { it.confidenceLevel!!.toDouble() }
            .average() * 20 // Convert to percentage (1-5 -> 20-100)
    }

    private fun generateHeatmapData(attempts: List<TestAttempt>): WritableArray {
        val heatmap = Arguments.createArray()
        
        attempts.flatMap { it.questions }.forEachIndexed { index, question ->
            val point = Arguments.createMap().apply {
                putInt("index", index)
                putInt("timeSpent", question.timeSpent)
                putBoolean("isCorrect", question.isCorrect)
                putString("topic", question.topic)
                putDouble("intensity", question.timeSpent / 120.0) // Normalize to 0-1
            }
            heatmap.pushMap(point)
        }
        
        return heatmap
    }

    private fun analyzeTimeUsage(attempts: List<TestAttempt>): TimeAnalysis {
        val allQuestions = attempts.flatMap { it.questions }
        
        if (allQuestions.isEmpty()) {
            return TimeAnalysis(0.0, emptyList(), emptyList(), 0.0)
        }
        
        val avgTime = allQuestions.map { it.timeSpent }.average()
        val sorted = allQuestions.sortedBy { it.timeSpent }
        
        val fastest = sorted.take(5).map { it.id }
        val slowest = sorted.takeLast(5).map { it.id }
        
        // Calculate efficiency: ratio of correct answers in optimal time
        val optimalTime = 60.0 // seconds
        val efficient = allQuestions.count { it.isCorrect && it.timeSpent <= optimalTime }
        val efficiency = (efficient.toDouble() / allQuestions.size) * 100
        
        return TimeAnalysis(
            averageTimePerQuestion = avgTime,
            fastestQuestions = fastest,
            slowestQuestions = slowest,
            timeEfficiencyScore = efficiency
        )
    }

    private fun generateRecommendation(accuracy: Double, avgTime: Double): String {
        return when {
            accuracy < 40 && avgTime > 90 -> "Focus on fundamentals, speed will come with practice"
            accuracy < 40 -> "Review concepts thoroughly"
            accuracy < 60 && avgTime > 90 -> "Practice more questions to improve speed"
            else -> "Keep practicing to improve"
        }
    }

    private data class RegressionResult(
        val slope: Double,
        val intercept: Double,
        val predicted: Double,
        val confidence: Double
    )

    private fun simpleLinearRegression(values: List<Double>): RegressionResult {
        val n = values.size
        val x = (0 until n).map { it.toDouble() }
        val y = values
        
        val xMean = x.average()
        val yMean = y.average()
        
        var numerator = 0.0
        var denominator = 0.0
        
        for (i in x.indices) {
            numerator += (x[i] - xMean) * (y[i] - yMean)
            denominator += (x[i] - xMean).pow(2)
        }
        
        val slope = if (denominator != 0.0) numerator / denominator else 0.0
        val intercept = yMean - slope * xMean
        
        // Predict next value
        val predicted = slope * n + intercept
        
        // Calculate R² for confidence
        val yPredicted = x.map { slope * it + intercept }
        val ssRes = y.zip(yPredicted).sumOf { (actual, pred) -> (actual - pred).pow(2) }
        val ssTot = y.sumOf { (it - yMean).pow(2) }
        val rSquared = if (ssTot != 0.0) 1 - (ssRes / ssTot) else 0.0
        
        return RegressionResult(
            slope = slope,
            intercept = intercept,
            predicted = predicted,
            confidence = max(0.0, rSquared) * 100
        )
    }

    private fun AnalyticsResult.toWritableMap(): WritableMap {
        return Arguments.createMap().apply {
            putDouble("overallAccuracy", overallAccuracy)
            putMap("topicAccuracy", topicAccuracy.toWritableMap())
            putMap("timeDistribution", timeDistribution.toWritableMap())
            putMap("difficultyPerformance", difficultyPerformance.toWritableMap())
            putMap("improvementTrend", improvementTrend.toWritableMap())
            putArray("weakTopics", weakTopics.toWritableArray())
            putArray("strongTopics", strongTopics.toWritableArray())
            putMap("predictedScore", predictedScore.toWritableMap())
            putDouble("confidenceScore", confidenceScore)
            putArray("heatmapData", heatmapData)
            putMap("timeAnalysis", timeAnalysis.toWritableMap())
        }
    }

    private fun Map<String, Double>.toWritableMap(): WritableMap {
        return Arguments.createMap().apply {
            forEach { (key, value) ->
                putDouble(key, value)
            }
        }
    }

    private fun List<TopicInsight>.toWritableArray(): WritableArray {
        return Arguments.createArray().apply {
            forEach { insight ->
                pushMap(Arguments.createMap().apply {
                    putString("topic", insight.topic)
                    putDouble("accuracy", insight.accuracy)
                    putInt("questionsAttempted", insight.questionsAttempted)
                    putDouble("averageTime", insight.averageTime)
                    putString("recommendation", insight.recommendation)
                })
            }
        }
    }

    private fun ImprovementTrend.toWritableMap(): WritableMap {
        return Arguments.createMap().apply {
            putDouble("slope", slope)
            putBoolean("isImproving", isImproving)
            putDouble("improvementRate", improvementRate)
        }
    }

    private fun ScorePrediction.toWritableMap(): WritableMap {
        return Arguments.createMap().apply {
            putDouble("predicted", predicted)
            putDouble("confidence", confidence)
            putDouble("slope", slope)
        }
    }

    private fun TimeAnalysis.toWritableMap(): WritableMap {
        return Arguments.createMap().apply {
            putDouble("averageTimePerQuestion", averageTimePerQuestion)
            putArray("fastestQuestions", Arguments.fromList(fastestQuestions))
            putArray("slowestQuestions", Arguments.fromList(slowestQuestions))
            putDouble("timeEfficiencyScore", timeEfficiencyScore)
        }
    }

    override fun onCatalystInstanceDestroy() {
        super.onCatalystInstanceDestroy()
        scope.cancel()
    }
}
